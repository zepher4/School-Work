import java.util.Scanner;

public class Errors3

	public static void main(String[] args) {
		Scanner kbd = new Scanner System.in;
		Int numerator;
		integer denominator;

		System.println("This program divides two numbers.");
		System.print("Enter the numerator: ");
		numerator = kbd.nextInt();
		System.out.print("Enter the denominator: ");
		denomintaor = kbd.nextInt();

		system.out.print(numerator);
		System.out.print("/");
		system.out.Print(denominator);
		System.out.print(" = ");
		System.out.Println((double) numerator/denominator);
	}
