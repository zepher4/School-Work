public class Errors1 {

	public static void main(String[] args) {
		System.out.println("Can you spot and fix the errors?);

		System.out.println("Enter two numbers and I ");
		System.out.println("add them for you");

		int n1, n2;

		Scanner keyboard = new Scanner(System.in)
		n1 = nextInt();
		n2 = nextint();

		System.println("The sum of the numbers is");
		System.out.println(n1 - n2);
	}
}